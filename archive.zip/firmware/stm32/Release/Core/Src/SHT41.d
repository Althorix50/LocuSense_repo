Core/Src/SHT41.o: ../Core/Src/SHT41.c ../Core/Inc/SHT41.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal.h \
 ../Core/Inc/stm32u0xx_hal_conf.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_rcc.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32U0xx/Include/stm32u0xx.h \
 ../Drivers/CMSIS/Device/ST/STM32U0xx/Include/stm32u073xx.h \
 ../Drivers/CMSIS/Include/core_cm0plus.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32U0xx/Include/system_stm32u0xx.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_rcc_ex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_gpio.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_gpio_ex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_dma.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_ll_dma.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_ll_dmamux.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_dma_ex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_cortex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_adc.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_ll_adc.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_adc_ex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_adc_ex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_exti.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_flash.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_flash_ex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_i2c.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_i2c_ex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_lptim.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_ll_lptim.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_pwr.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_pwr_ex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_rtc.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_rtc_ex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_spi.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_spi_ex.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_uart.h \
 ../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_uart_ex.h
../Core/Inc/SHT41.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal.h:
../Core/Inc/stm32u0xx_hal_conf.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_rcc.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32U0xx/Include/stm32u0xx.h:
../Drivers/CMSIS/Device/ST/STM32U0xx/Include/stm32u073xx.h:
../Drivers/CMSIS/Include/core_cm0plus.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32U0xx/Include/system_stm32u0xx.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_rcc_ex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_gpio.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_gpio_ex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_dma.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_ll_dma.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_ll_dmamux.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_dma_ex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_cortex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_adc.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_ll_adc.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_adc_ex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_adc_ex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_exti.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_flash.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_flash_ex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_i2c.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_i2c_ex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_lptim.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_ll_lptim.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_pwr.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_pwr_ex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_rtc.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_rtc_ex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_spi.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_spi_ex.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_uart.h:
../Drivers/STM32U0xx_HAL_Driver/Inc/stm32u0xx_hal_uart_ex.h:
